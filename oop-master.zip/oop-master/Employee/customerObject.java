package Employee;

public class customerObject {
        public int gameID;
        public String name;
        public customerObject (int gameID, String name){
            this.gameID=gameID;
            this.name=name;
        }
    }
