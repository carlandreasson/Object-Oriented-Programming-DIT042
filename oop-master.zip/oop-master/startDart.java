import Menus.Menu;

public class startDart {
    public static void main(String[] args) {
        Menu.menu();
    }
}
